package sorter;

/**
 *
 * @author kdbanman
 */
public class InterfaceException extends Exception {
    
    public InterfaceException(String msg) {
        super(msg);
    }
}
