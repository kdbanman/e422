package sorter;

/**
 *
 * @author kdbanman
 */
public class FailureException extends Exception {
    
    public FailureException(String msg) {
        super(msg);
    }
}
