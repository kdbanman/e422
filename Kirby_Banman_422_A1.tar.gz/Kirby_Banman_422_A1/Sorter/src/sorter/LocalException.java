package sorter;

/**
 *
 * @author kdbanman
 */
public class LocalException extends Exception {
    
    public LocalException(String msg) {
        super(msg);
    }
}
